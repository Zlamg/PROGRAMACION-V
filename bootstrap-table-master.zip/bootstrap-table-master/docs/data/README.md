# Data for jsFiddle

Detail: [Pass response directly from GitHub Repository](http://doc.jsfiddle.net/use/github_response.html)